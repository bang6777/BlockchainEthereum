if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
} else {
    // set the provider you want from Web3.providers
    web3 = new Web3(new Web3.providers.HttpProvider("https://rinkeby.infura.io/v3/6e2f01b49b384897a521b1ecbba415cd"));
}
ethereum.enable();
var thumuaInstance = new web3.eth.Contract(thumuaABI, "0x175e4823e7a4688e333097182c0E711BEdA8FBC0");
var temp = web3.eth.accounts.create();
var randomAddress = temp.address;
function addthumua() {
	if ($('#Insertthumuaform').parsley().validate()) {
        web3.eth.getAccounts(function (error, result) {
        	var temp = web3.eth.accounts.create();
            var id = temp.address;
            var nguoithumua =$("#nguoithumua").val();
            var noithumua = $("#noithumua").val();
            var cachthucthumua =$("#cachthucthumua").val();
            var donggoi =$("#donggoi").val();
            var baoquan =$("#baoquan").val();
            var thoigiantao= new Date(Date.now()).toLocaleString();
            var thoigianchinhsua= new Date(Date.now()).toLocaleString();
            var trangthai = $("#trangthai").val();
            var batch = new web3.BatchRequest();
            var ac = result[0];
            console.log(ac);
            batch.add(thumuaInstance.methods.insertthumua(id,nguoithumua,noithumua,cachthucthumua,donggoi,baoquan)
                .send({
                    from: ac
                }, function (error, result) { 
                    try {
                        if (error.message.includes("User denied transaction signature")) {
                            alert("Denied transaction!");
                          //  location.reload();
                        }
                        console.log(noithumua);

                    }
                    catch (err) {
                        // console.log(err);
                        // console.log(noithumua);
                        // console.log("OK Loi~");
                    }
                }
            ));
            batch.add(thumuaInstance.methods.insertthumuadetail(id,thoigiantao,thoigianchinhsua,trangthai)
                .send({
                    from: ac
                }, function (error, result) { 
                    try {
                        if (error.message.includes("User denied transaction signature")) {
                            alert("Denied transaction!");
                          //  location.reload();
                        }
                        console.log(noithumua);

                    }
                    catch (err) {
                        // console.log(err);
                        // console.log(noithumua);
                        // console.log("OK Loi~");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#Insertthumuaform").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thêm thành công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {
                location.reload();
            })
            .on('error', console.err)
            );
            try {
                batch.execute();
                if (error.message.includes("JSONRPC method should be specified for params:")) {
                    console.log("Đã fix lỗi.");
                }
            }
            catch (err) {
                console.log("Đã fix lỗi.");
            }
        });
    }
}

function pag() {
    $('#paginationthumua').html('')
    var table = '#thumua';
    var trnum = 0;
    var maxRows = 5;
    var totalRows = $('#thumua tbody tr').length;
    // console.log(totalRows);
    $(table + ' tr:gt(0)').each(function () {
        trnum++
        if (trnum > maxRows) {
            $(this).hide()
        }
        if (trnum <= maxRows) {
            $(this).show()
        }
    })
    if (totalRows > maxRows) {
        var pagenum = Math.ceil(totalRows / maxRows)
        for (var i = 1; i <= pagenum;) {
            $('#paginationthumua').append('<li data-page="' + i + '">\<span>' + i++ + ' <span class="sr-only">(current)</span> </span>\ </li>').show()
        }
    }
    $('#paginationthumua li:first-child').addClass('active')
    $('#paginationthumua li').on('click', function () {
        var pageNum = $(this).attr('data-page')
        var trIndex = 0
        $('#paginationthumua li').removeClass('active')
        $(this).addClass('active')
        $(table + ' tr:gt(0)').each(function () {
            trIndex++
            if (trIndex > (maxRows * pageNum) || trIndex <= ((maxRows * pageNum) - maxRows)) {
                $(this).hide()
            } else {
                $(this).show()
            }
        })
    })
}
// load page
$(window).on('load', function () {
    listthumuaManagement();
    $(document).ready(function () {
        var table = '#thumua';
        var totalRows = $('#thumua tbody tr').length;
        var maxRows=5;
        setTimeout(pag, 4000);
        if (totalRows > maxRows) {
                var pagenum = Math.ceil(totalRows / maxRows)
                for (var i = 1; i <= pagenum;) {
                    $('.pagination').append('<li data-page="' + i + '">\<span>' + i++ + '<span class="sr-only">(current)</span> </span>\ </li>').show()
                }
            }
            $('.pagination li:first-child').addClass('active')
            $('.pagination li').on('click', function () {
                var pageNum = $(this).attr('data-page')
                var trIndex = 0
                $('.pagination li').removeClass('active')
                $(this).addClass('active')
                $(table + ' tr:gt(0)').each(function () {
                    trIndex++
                    if (trIndex > (maxRows * pageNum) || trIndex <= ((maxRows * pageNum) - maxRows)) {
                        $(this).hide()
                    } else {
                        $(this).show()
                    }
                })
            })
        })
    });
//modal view thumua
function viewthumua(id) {
    console.log(id);
    thumuaInstance.methods.getthumua(id).call().then(function (result) {
         
            var table = `<tr>
                                      
                                            <td>` + result[0] + `</td>
                                       
                                            <td>` + result[1] + `</td>
                                        
                                           
                                            <td>` + result[2] + `</td>
                                        
                                  
                                            <td>` + result[3] + `</td>
                                       
                                            <td>` + result[4] + `</td>

                                            <td>` + result[4] + `</td>
                                        </tr>`;
            $("#thumua").find("tbody").html(table);
        })
    
}
//Danh sach cay giong
function listthumuaManagement() {
    var table = "";
    thumuaInstance.methods.getthumuaCount().call().then(function (count) {
        
        console.log(count);
        for (let row = 0; row < count; row++) {
            thumuaInstance.methods.getthumuaAtIndex(row).call().then(function (addr) {
                thumuaInstance.methods.getthumua(addr).call().then(function (result) {
                    thumuaInstance.methods.getthumuadetail(addr).call().then(function (result1) {
                      
                        // console.log(result1);
                        table += `<tr>
                                        <td>
                                        <button class="btn btn-primary btn-xs"
                                        data-toggle="modal" data-target="#updatethumuaModal"
                                        onclick="frontUpdatethumua(
                                            
                                            \`` + result[0] + `\`,
                                            \`` + result[1] + `\`,
                                            \`` + result[2] + `\`,
                                            \`` + result[3] + `\`,
                                            \`` + result[4] + `\`,
                                            \`` + result[5] + `\`,
                                            \`` + result[6] + `\`,

                                            \`` + result1[1] + `\`,
                                            \`` + result1[2] + `\`,
                                            \`` + result1[3] + `\`" >
                                        <i class="far fa-edit"></i>
                                            Update
                                        </button>
                                        </td>
                                        <td>` + (parseInt(row) + 1) + `</td>
                                        <td>` + result[0] + `</td>
                                        <td>` + result[1] + `</td>
                                        <td>` + result[2] + `</td>
                                        <td>` + result[3] + `</td>
                                        <td>` + result[4] + `</td>
                                        <td>` + result[5] + `</td>

                                        <td>` + result1[1] + `</td>
                                        <td>` + result1[2] + `</td>
                                        <td>` + result1[3] + `</td>

                                    </tr>`;
                        $("#thumua").find("tbody").html(table);
            
                    })
                })
            })
        }
    })
}
//Update
function updatenguoithumuajs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatenguoithumua .modal-body p').text();
        var fullName = $('#valueUpdatenguoithumua').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(thumuaInstance.methods.updatenguoithumua(address, fullName, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatenguoithumua").hide();
                $("#frontUpdatethumua").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatenoithumuajs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatenoithumua .modal-body p').text();
        var noithumua = $('#valueUpdatenoithumua').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(thumuaInstance.methods.updatenoithumua(address, noithumua, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatenoithumua").hide();
                $("#frontUpdatethumua").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatecachthucthumuajs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatecachthucthumua .modal-body p').text();
        var cachthucthumua = $('#valueUpdatecachthucthumua').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(thumuaInstance.methods.updatecachthucthumua(address, cachthucthumua, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatecachthucthumua").hide();
                $("#frontUpdatethumua").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatedonggoijs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatedonggoi .modal-body p').text();
        var donggoi = $('#valueUpdatedonggoi').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(thumuaInstance.methods.updatedonggoi(address, donggoi, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatedonggoi").hide();
                $("#frontUpdatethumua").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatebaoquanjs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatebaoquan .modal-body p').text();
        var baoquan = $('#valueUpdatethovu').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(thumuaInstance.methods.updatebaoquan(address, baoquan, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatebaoquan").hide();
                $("#frontUpdatethumua").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}

//modal comfirm update
function createUpdatenguoithumua(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatenguoithumua").find(".modal-body2").html(parag);
}

function createUpdatenoithumua(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatenoithumua").find(".modal-body2").html(parag);
}
function createUpdatecachthucthumua(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatecachthucthumua").find(".modal-body2").html(parag);
}
function createUpdatedonggoi(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatedonggoi").find(".modal-body2").html(parag);
}
function createUpdatebaoquan(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatebaoquan").find(".modal-body2").html(parag);
}
function createUpdateisLock(address) {
    var parag = `<p>` + address + `</p>`;
    $("#trangthai").find(".modal-body2").html(parag);
}
//model update school
function frontUpdatethumua(address, nguoithumua, noithumua, cachthucthumua, donggoi, baoquan,soluong,dientich, createdTime, modifiedTime, isLocked) {
    var table = "";
    table += `<tr>
                    <th>Address</th>
                    <td id="tdAddress">`+ address + `</td>
                    <td></td>
                <tr>
                    <th>Tên Cây</th>
                    <td id="tdFullName">`+ nguoithumua + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatenguoithumua"
                        onclick="createUpdatenguoithumua(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                
                <tr>
                    <th>Khu vưc trồng</th>
                    <td id="kvtrong">`+ noithumua + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatenoithumua"
                        onclick="createUpdatenoithumua(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                    <th>Người  Trồng</th>
                    <td id="cachthucthumua">`+ cachthucthumua + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatecachthucthumua"
                        onclick="createUpdatecachthucthumua(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                    <th>Phân bón</th>
                    <td id="pb">`+ donggoi + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatedonggoi"
                        onclick="createUpdatedonggoi(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                    <th>Thời vụ</th>
                    <td id="tv">`+ baoquan + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatebaoquan"
                        onclick="createUpdatebaoquan(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                
                
                <tr>
                    <th>Trạng thái</th>
                    <td id="tdisLocked">`+ isLocked + `</td>
                    <td></td>
                </tr>
                <tr>
                    <th>Thời gian tạo</th>
                    <td id="tdCreatedTime">`+ createdTime + `</td>
                    <td></td>
                </tr>
                <tr>
                    <th>Thời gian thay đổi</th>
                    <td id="tdModifiedTime">`+ modifiedTime + `</td>
                    <td></td>
                </tr>
                <tr>
                    <td>
                    <button type="button" class="btn btn-danger btn-xs" data-dismiss="modal"> <i class="far fa-trash-alt"></i>Hủy</button>
                    </td>
                </tr>`;
    $("#updatethumuaModal").find("tbody").html(table);
}