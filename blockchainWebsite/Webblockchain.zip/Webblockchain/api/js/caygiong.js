if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
} else {
    // set the provider you want from Web3.providers
    web3 = new Web3(new Web3.providers.HttpProvider("https://rinkeby.infura.io/v3/6e2f01b49b384897a521b1ecbba415cd"));
}
ethereum.enable();
var caygiongInstance = new web3.eth.Contract(caygiongABI, "0xf15d9fDD39E5B0FEd30ebe1F80Cf16E698aD7f3c");
var temp = web3.eth.accounts.create();
var randomAddress = temp.address;
function addCaygiong() {
	if ($('#InsertCaygiongform').parsley().validate()) {
        web3.eth.getAccounts(function (error, result) {
        	var temp = web3.eth.accounts.create();
            var id = temp.address;
            var tencaytrong =$("#tencay").val();
            var khuvuctrong = $("#khuvuctrong").val();
            var nguoitrong =$("#nguoitrong").val();
            var phanbon =$("#phanbon").val();
            var thoivu =$("#thoivu").val();
            var dientich =$("#dientich").val();
            var soluong = $("#soluong").val();
            var thoigiantao= new Date(Date.now()).toLocaleString();
            var thoigianchinhsua= new Date(Date.now()).toLocaleString();
            var trangthai = $("#trangthai").val();
            var batch = new web3.BatchRequest();
            var ac = result[0];
            console.log(ac);
            batch.add(caygiongInstance.methods.insertCaygiong(id,tencaytrong,khuvuctrong,nguoitrong,phanbon,thoivu)
                .send({
                    from: ac
                }, function (error, result) { 
                    try {
                        if (error.message.includes("User denied transaction signature")) {
                            alert("Denied transaction!");
                          //  location.reload();
                        }
                        console.log(khuvuctrong);

                    }
                    catch (err) {
                        // console.log(err);
                        // console.log(khuvuctrong);
                        // console.log("OK Loi~");
                    }
                }
            ));
            batch.add(caygiongInstance.methods.insertCaygiongdetail(id,dientich,soluong,thoigiantao,thoigianchinhsua,trangthai)
                .send({
                    from: ac
                }, function (error, result) { 
                    try {
                        if (error.message.includes("User denied transaction signature")) {
                            alert("Denied transaction!");
                          //  location.reload();
                        }
                        console.log(khuvuctrong);

                    }
                    catch (err) {
                        // console.log(err);
                        // console.log(khuvuctrong);
                        // console.log("OK Loi~");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#addUsers").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thêm thành công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {
                location.reload();
            })
            .on('error', console.err)
            );
            try {
                batch.execute();
                if (error.message.includes("JSONRPC method should be specified for params:")) {
                    console.log("Đã fix lỗi.");
                }
            }
            catch (err) {
                console.log("Đã fix lỗi.");
            }
        });
    }
}

function pag() {
    $('#paginationCaygiong').html('')
    var table = '#caygiong';
    var trnum = 0;
    var maxRows = 5;
    var totalRows = $('#caygiong tbody tr').length;
    // console.log(totalRows);
    $(table + ' tr:gt(0)').each(function () {
        trnum++
        if (trnum > maxRows) {
            $(this).hide()
        }
        if (trnum <= maxRows) {
            $(this).show()
        }
    })
    if (totalRows > maxRows) {
        var pagenum = Math.ceil(totalRows / maxRows)
        for (var i = 1; i <= pagenum;) {
            $('#paginationCaygiong').append('<li data-page="' + i + '">\<span>' + i++ + ' <span class="sr-only">(current)</span> </span>\ </li>').show()
        }
    }
    $('#paginationCaygiong li:first-child').addClass('active')
    $('#paginationCaygiong li').on('click', function () {
        var pageNum = $(this).attr('data-page')
        var trIndex = 0
        $('#paginationCaygiong li').removeClass('active')
        $(this).addClass('active')
        $(table + ' tr:gt(0)').each(function () {
            trIndex++
            if (trIndex > (maxRows * pageNum) || trIndex <= ((maxRows * pageNum) - maxRows)) {
                $(this).hide()
            } else {
                $(this).show()
            }
        })
    })
}
// load page
$(window).on('load', function () {
    listCaygiongManagement();
    $(document).ready(function () {
        var table = '#caygiong';
        var totalRows = $('#caygiong tbody tr').length;
        var maxRows=5;
        setTimeout(pag, 4000);
        if (totalRows > maxRows) {
                var pagenum = Math.ceil(totalRows / maxRows)
                for (var i = 1; i <= pagenum;) {
                    $('.pagination').append('<li data-page="' + i + '">\<span>' + i++ + '<span class="sr-only">(current)</span> </span>\ </li>').show()
                }
            }
            $('.pagination li:first-child').addClass('active')
            $('.pagination li').on('click', function () {
                var pageNum = $(this).attr('data-page')
                var trIndex = 0
                $('.pagination li').removeClass('active')
                $(this).addClass('active')
                $(table + ' tr:gt(0)').each(function () {
                    trIndex++
                    if (trIndex > (maxRows * pageNum) || trIndex <= ((maxRows * pageNum) - maxRows)) {
                        $(this).hide()
                    } else {
                        $(this).show()
                    }
                })
            })
        })
    });
//modal view caygiong
function viewCaygiong(id) {
    console.log(id);
    caygiongInstance.methods.getCaygiong(id).call().then(function (result) {
         
            var table = `<tr>
                                      
                                            <td>` + result[0] + `</td>
                                       
                                            <td>` + result[1] + `</td>
                                        
                                           
                                            <td>` + result[2] + `</td>
                                        
                                  
                                            <td>` + result[3] + `</td>
                                       
                                            <td>` + result[4] + `</td>

                                            <td>` + result[4] + `</td>
                                        </tr>`;
            $("#caygiong").find("tbody").html(table);
        })
    
}
//Danh sach cay giong
function listCaygiongManagement() {
    var table = "";
    caygiongInstance.methods.getCaygiongCount().call().then(function (count) {
        
        console.log(count);
        for (let row = 0; row < count; row++) {
            caygiongInstance.methods.getCaygiongAtIndex(row).call().then(function (addr) {
                caygiongInstance.methods.getCaygiong(addr).call().then(function (result) {
                    caygiongInstance.methods.getCaygiongdetail(addr).call().then(function (result1) {
                      
                        // console.log(result1);
                        table += `<tr>
                                        <td>
                                        <button class="btn btn-primary btn-xs"
                                        data-toggle="modal" data-target="#updatecaygiongModal"
                                        onclick="frontUpdatecaygiong(
                                            
                                            \`` + result[0] + `\`,
                                            \`` + result[1] + `\`,
                                            \`` + result[2] + `\`,
                                            \`` + result[3] + `\`,
                                            \`` + result[4] + `\`,
                                            \`` + result[5] + `\`,

                                            \`` + result1[1] + `\`,
                                            \`` + result1[2] + `\`,
                                            \`` + result1[3] + `\`,
                                            \`` + result1[4] + `\`,
                                            \`` + result1[5] + `\`)" >
                                        <i class="far fa-edit"></i>
                                            Update
                                        </button>
                                        </td>
                                        <td>` + (parseInt(row) + 1) + `</td>
                                        <td>` + result[0] + `</td>
                                        <td>` + result[1] + `</td>
                                        <td>` + result[2] + `</td>
                                        <td>` + result[3] + `</td>
                                        <td>` + result[4] + `</td>
                                        <td>` + result[5] + `</td>

                                        <td>` + result1[1] + `</td>
                                        <td>` + result1[2] + `</td>
                                        <td>` + result1[3] + `</td>
                                        <td>` + result1[4] + `</td>
                                        <td>` + result1[5] + `</td>
                                    </tr>`;
                        $("#caygiong").find("tbody").html(table);
            
                    })
                })
            })
        }
    })
}
//Update
function updatetencayjs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatetencay .modal-body p').text();
        var fullName = $('#valueUpdatetencay').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(caygiongInstance.methods.updatetencay(address, fullName, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatetencay").hide();
                $("#frontUpdatecaygiong").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatekhuvuctrongjs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatekhuvuctrong .modal-body p').text();
        var khuvuctrong = $('#valueUpdatekhuvuctrong').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(caygiongInstance.methods.updatekhuvuctrong(address, khuvuctrong, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatekhuvuctrong").hide();
                $("#frontUpdatecaygiong").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatenguoitrongjs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatenguoitrong .modal-body p').text();
        var nguoitrong = $('#valueUpdatenguoitrong').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(caygiongInstance.methods.updatenguoitrong(address, nguoitrong, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatenguoitrong").hide();
                $("#frontUpdatecaygiong").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatephanbonjs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatephanbon .modal-body p').text();
        var phanbon = $('#valueUpdatephanbon').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(caygiongInstance.methods.updatephanbon(address, phanbon, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatephanbon").hide();
                $("#frontUpdatecaygiong").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatethoivujs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatethoivu .modal-body p').text();
        var thoivu = $('#valueUpdatethovu').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(caygiongInstance.methods.updatethoivu(address, thoivu, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatethoivu").hide();
                $("#frontUpdatecaygiong").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatesoluongjs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatesoluong .modal-body p').text();
        var soluong = $('#valueUpdatesoluong').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(caygiongInstance.methods.updatenguoitrong(address, soluong, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatesoluong").hide();
                $("#frontUpdatecaygiong").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
function updatedientichjs() {
    web3.eth.getAccounts(function (error, result) {
        var account = result[0];
        var address = $('#updatedientich .modal-body p').text();
        var dientich = $('#valueUpdatedientich').val();
        var modifiedTime = new Date(Date.now()).toString();
        var batch = new web3.BatchRequest();
        batch.add(caygiongInstance.methods.updatenguoitrong(address, dientich, modifiedTime)
            .send({ from: account },
                function (error, result) {
                    try {
                        if (error.message.includes("Cay giong denied transaction signature")) {
                            alert('Đã từ chối dịch vụ.');
                            location.reload();
                        }
                    }
                    catch (err) {
                        console.log("Đã fix lỗi.");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#updatedientich").hide();
                $("#frontUpdatecaygiong").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thành Công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {

            })
            .on('error', console.err)
        );
        try {
            batch.execute();
            if (error.message.includes("JSONRPC method should be specified for params:")) {
                console.log("Đã fix lỗi.");
            }
        }
        catch (err) {
            console.log("Đã fix lỗi.");
        }
    })
}
//modal comfirm update
function createUpdatetencay(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatetencay").find(".modal-body2").html(parag);
}

function createUpdatekhuvuctrong(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatekhuvuctrong").find(".modal-body2").html(parag);
}
function createUpdatenguoitrong(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatenguoitrong").find(".modal-body2").html(parag);
}
function createUpdatephanbon(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatephanbon").find(".modal-body2").html(parag);
}
function createUpdatethoivu(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatethoivu").find(".modal-body2").html(parag);
}
function createUpdatesoluong(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatesoluong").find(".modal-body2").html(parag);
}
function createUpdatedientich(address) {
    var parag = `<p>` + address + `</p>`;
    $("#updatedientich").find(".modal-body2").html(parag);
}
function createUpdateisLock(address) {
    var parag = `<p>` + address + `</p>`;
    $("#trangthai").find(".modal-body2").html(parag);
}
//model update school
function frontUpdatecaygiong(address, tencay, khuvuctrong, nguoitrong, phanbon, thoivu,soluong,dientich, createdTime, modifiedTime, isLocked) {
    var table = "";
    table += `<tr>
                    <th>Address</th>
                    <td id="tdAddress">`+ address + `</td>
                    <td></td>
                <tr>
                    <th>Tên Cây</th>
                    <td id="tdFullName">`+ tencay + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatetencay"
                        onclick="createUpdatetencay(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                
                <tr>
                    <th>Khu vưc trồng</th>
                    <td id="kvtrong">`+ khuvuctrong + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatekhuvuctrong"
                        onclick="createUpdatekhuvuctrong(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                    <th>Người  Trồng</th>
                    <td id="nguoitrong">`+ nguoitrong + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatenguoitrong"
                        onclick="createUpdatenguoitrong(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                    <th>Phân bón</th>
                    <td id="pb">`+ phanbon + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatephanbon"
                        onclick="createUpdatephanbon(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                    <th>Thời vụ</th>
                    <td id="tv">`+ thoivu + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatethoivu"
                        onclick="createUpdatethoivu(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                    <th>Số lượng</th>
                    <td id="sl">`+ soluong + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatesoluong"
                        onclick="createUpdatesoluong(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                    <th>Diện tích</th>
                    <td id="sl">`+ dientich + `</td>
                    <td>
                        <button class="btn btn-primary btn-xs"
                        data-toggle="modal" data-target="#updatedientich"
                        onclick="createUpdatedientich(\`` + address + `\`)" >
                        <i class="far fa-edit"></i>
                            Sửa
                        </button>
                    </td>
                </tr>
                <tr>
                <tr>
                    <th>Trạng thái</th>
                    <td id="tdisLocked">`+ isLocked + `</td>
                    <td></td>
                <tr>
                <tr>
                    <th>Thời gian tạo</th>
                    <td id="tdCreatedTime">`+ createdTime + `</td>
                    <td></td>
                </tr>
                <tr>
                    <th>Thời gian thay đổi</th>
                    <td id="tdModifiedTime">`+ modifiedTime + `</td>
                    <td></td>
                </tr>
                <tr>
                    <td>
                    <button type="button" class="btn btn-danger btn-xs" data-dismiss="modal"> <i class="far fa-trash-alt"></i>Hủy</button>
                    </td>
                </tr>`;
    $("#updatecaygiongModal").find("tbody").html(table);
}