var qrcode = new QRCode("id_qrcode", {
	text:"www.stdio.vn",
	width:100,
	height:100,
	colorDark:"#000000",
	colorLight:"#ffffff",
	correctLevel:QRCode.CorrectLevel.H
});