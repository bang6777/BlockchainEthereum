var sanphamABI=[
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "index",
				"type": "uint256"
			}
		],
		"name": "SetLogDeletesanphamManagement",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Nguoibanle",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Noibanle",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Cachthucbanle",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Baoquanbanle",
				"type": "string"
			}
		],
		"name": "Setbanle",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Khuvuctrongcayantrai",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Nguoitrongcayantrai",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Phanboncayantrai",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Thoivucayantrai",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Soluongcayantrai",
				"type": "string"
			}
		],
		"name": "Setcayantrai",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Khuvuctrongcaygiong",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Nguoitrongcaygiong",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Phanboncaygiong",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Thoivucaygiong",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Soluongcaygiong",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Dientichcaygiong",
				"type": "string"
			}
		],
		"name": "Setcaygiong",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Diadiemnhan",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Noiphanphoi",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Cachthucphanphoi",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Donggoiphanphoi",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Baoquanphanphoi",
				"type": "string"
			}
		],
		"name": "Setphanphoi",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Tensanpham",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_anh",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_thoigiantao",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_thoigianchinhsua",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_trangthai",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "_index",
				"type": "uint256"
			}
		],
		"name": "Setsanpham",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Nguoithumua",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Noithumua",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_Cachthucthumua",
				"type": "string"
			}
		],
		"name": "Setthumua",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_tensanpham",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_anh",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_thoigianchinhsua",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "_trangthai",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "index",
				"type": "uint256"
			}
		],
		"name": "updatesanpham",
		"type": "event"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "address",
				"name": "_sanphamAddress",
				"type": "address"
			}
		],
		"name": "deletesanpham",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "index",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			}
		],
		"name": "getCaygiong",
		"outputs": [
			{
				"internalType": "address",
				"name": "Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Khuvuctrongcaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Nguoitrongcaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Phanboncaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Thoivucaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Soluongcaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Dientichcaygiong",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			}
		],
		"name": "getbanle",
		"outputs": [
			{
				"internalType": "address",
				"name": "Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Nguoibanle",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Noibanle",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Cachthucbanle",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Baoquanbanle",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			}
		],
		"name": "getcayantrai",
		"outputs": [
			{
				"internalType": "address",
				"name": "Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Khuvuctrongcayantrai",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Nguoitrongcayantrai",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Phanboncayantrai",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Thoivucayantrai",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Soluongcayantrai",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			}
		],
		"name": "getphanphoi",
		"outputs": [
			{
				"internalType": "address",
				"name": "Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Diadiemnhan",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Noiphanphoi",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Cachthucphanphoi",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Donggoiphanphoi",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Baoquanphanphoi",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			}
		],
		"name": "getsanpham",
		"outputs": [
			{
				"internalType": "address",
				"name": "Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Tensanpham",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_anh",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_thoigiantao",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_thoigianchinhsua",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_trangthai",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_index",
				"type": "uint256"
			}
		],
		"name": "getsanphamAtIndex",
		"outputs": [
			{
				"internalType": "address",
				"name": "Idsanpham",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getsanphamCount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "count",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			}
		],
		"name": "getthumua",
		"outputs": [
			{
				"internalType": "address",
				"name": "Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Nguoithumua",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Noithumua",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Cachthucthumua",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Khuvuctrongcaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Nguoitrongcaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Phanboncaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Thoivucaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Soluongcaygiong",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Dientichcaygiong",
				"type": "string"
			}
		],
		"name": "insertCaygiong",
		"outputs": [
			{
				"internalType": "bool",
				"name": "success",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Nguoibanle",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Noibanle",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Cachthucbanle",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Baoquanbanle",
				"type": "string"
			}
		],
		"name": "insertbanle",
		"outputs": [
			{
				"internalType": "bool",
				"name": "success",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Khuvuctrongcayantrai",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Nguoitrongcayantrai",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Phanboncayantrai",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Thoivucayantrai",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Soluongcayantrai",
				"type": "string"
			}
		],
		"name": "insertcayantrai",
		"outputs": [
			{
				"internalType": "bool",
				"name": "success",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Diadiemnhan",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Noiphanphoi",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Cachthucphanphoi",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Donggoiphanphoi",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Baoquanphanphoi",
				"type": "string"
			}
		],
		"name": "insertphanphoi",
		"outputs": [
			{
				"internalType": "bool",
				"name": "success",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Tensanpham",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_anh",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_thoigiantao",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_thoigianchinhsua",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_trangthai",
				"type": "string"
			}
		],
		"name": "insertsanpham",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "index",
				"type": "uint256"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_Nguoithumua",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Noithumua",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_Cachthucthumua",
				"type": "string"
			}
		],
		"name": "insertthumua",
		"outputs": [
			{
				"internalType": "bool",
				"name": "success",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			}
		],
		"name": "issanpham",
		"outputs": [
			{
				"internalType": "bool",
				"name": "isIndeed",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"internalType": "address",
				"name": "_Idsanpham",
				"type": "address"
			},
			{
				"internalType": "string",
				"name": "_thoigianchinhsua",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_trangthai",
				"type": "string"
			}
		],
		"name": "updatetrangthai",
		"outputs": [
			{
				"internalType": "bool",
				"name": "success",
				"type": "bool"
			}
		],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	}
]