if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
} else {
    // set the provider you want from Web3.providers
    web3 = new Web3(new Web3.providers.HttpProvider("https://rinkeby.infura.io/v3/254c4bff32bb42aead82bc5a2013286c"));
}
ethereum.enable();
var userInstance = new web3.eth.Contract(userABI, "0x30EA0B253B0db92e20873C0b43f0A151F9392961");
var temp = web3.eth.accounts.create();
var randomAddress = temp.address;

function addUser() {
	if ($('#InsertUserform').parsley().validate()){
        web3.eth.getAccounts(function (error, result) {
        	var temp = web3.eth.accounts.create();
            var id = temp.address;
            var tennguoidung =$("#tennguoidung").val();
            var email = $("#email").val();
            var pass =$("#pass").val();
            var gioitinh =$(".gender").val();
            var ngaysinh = $("#ngaysinh").val();
            var sdt =$("#sdt").val();
            var diachi =$("#diachi").val();
            var thoigiantao= new Date(Date.now()).toLocaleString();
            var thoigianchinhsua= new Date(Date.now()).toLocaleString();
            var batch = new web3.BatchRequest();
            var ac = result[0];
            console.log(ac);
            batch.add(userInstance.methods.insertUser(id,tennguoidung,email,pass,gioitinh,ngaysinh).send({from: ac}),
            batch.add(userInstance.methods.insertUserDetail(id,thoigiantao,thoigianchinhsua).send({from: ac}),
            batch.add(userInstance.methods.insertUserDetailFlus(id,sdt,"",diachi)
                .send({
                    from: ac
                }, function (error, result) { 
                    try {
                        if (error.message.includes("User denied transaction signature")) {
                            alert("Denied transaction!");
                          //  location.reload();
                        }
                        console.log(khuvuctrong);

                    }
                    catch (err) {
                        // console.log(err);
                        // console.log(khuvuctrong);
                        // console.log("OK Loi~");
                    }
                }
            )
            .on('transactionHash', (hash) => {
                $("#adduser").hide();
                alert("Vui lòng chờ xử lý giao dịch!");
            })
            .on('receipt', (receipt) => {
                alert("Thêm thành công!");
                location.reload();
            })
            .on('confirmation', (confirmationNumber, receipt) => {
                location.reload();
            })
            .on('error', console.err)
            )));
            try {
                batch.execute();
                if (error.message.includes("JSONRPC method should be specified for params:")) {
                    console.log("Đã fix lỗi.");
                }
            }
            catch (err) {
                console.log("Đã fix lỗi.");
            }
        });
    }
}
$(window).on('load', function () {
    listUserManagement();
   
 });
 function listUserManagement() {
    var table = "";
    userInstance.methods.getUserCount().call().then(function (count) {
        
        console.log(count);
        for (let row = 0; row < count; row++) {
            userInstance.methods.getUserAtIndex(row).call().then(function (addr) {
                userInstance.methods.getUser(addr).call().then(function (result) {
                    userInstance.methods.getUserDetailMore(addr).call().then(function (result1) {
                        userInstance.methods.getUserDetailMoreMore(addr).call().then(function (result2) {
                        // console.log(result1);
                        table += `<tr>
                                        <td>
                                        <button class="btn btn-primary btn-xs"
                                        data-toggle="modal" data-target="#updatecaygiongModal"
                                        onclick="frontUpdatecaygiong(
                                            
                                            \`` + result[0] + `\`,
                                            \`` + result[1] + `\`,
                                            \`` + result[2] + `\`,
                                            \`` + result[3] + `\`,
                                            \`` + result[4] + `\`,
                                            \`` + result[5] + `\`,

                                            \`` + result1[1] + `\`,
                                            \`` + result1[2] + `\`,
                                            \`` + result1[3] + `\`,
                                            \`` + result1[4] + `\`,
                                            \`` + result1[5] + `\`)" >
                                        <i class="far fa-edit"></i>
                                            Update
                                        </button>
                                        </td>
                                        <td>` + (parseInt(row) + 1) + `</td>
                                        <td>` + result[0] + `</td>
                                        <td>` + result[1] + `</td>
                                        <td>` + result[2] + `</td>
                                        <td>` + result[3] + `</td>
                                        <td>` + result[4] + `</td>
                                        <td>` + result[5] + `</td>
                                    
                                        <td>` + result1[0] + `</td>
                                        <td>` + result1[1] + `</td>
                                        <td>` + result2[0] + `</td>
                                        <td>` + result2[2] + `</td>
                                    </tr>`;
                        $("#user").find("tbody").html(table);
            
                    })
                })
                })
            })
        }
    })
}