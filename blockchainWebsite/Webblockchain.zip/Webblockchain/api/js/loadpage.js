var div = document.getElementById('loading');
            div.style.display = "block";
            setTimeout(function () {
            div.style.display = "none";
        }, 1000);